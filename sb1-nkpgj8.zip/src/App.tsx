import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import ModelSelection from './components/ModelSelection';
import LearningStyles from './components/LearningStyles';
import AlgorithmSelection from './components/AlgorithmSelection';
import MemoryOptions from './components/MemoryOptions';
import ResearchMode from './components/ResearchMode';
import RewardsManager from './components/RewardsManager';
import TrainingSchedule from './components/TrainingSchedule';
import MonitoringControl from './components/MonitoringControl';
import VideoTraining from './components/VideoTraining';
import AdvancedLogging from './components/AdvancedLogging';
import Pipeline from './components/Pipeline';
import ApiManager from './components/ApiManager';
import Settings from './components/Settings';
import AutoLearningMode from './components/AutoLearningMode';

function App() {
  return (
    <Router>
      <div className="flex h-screen bg-gray-100">
        <Sidebar />
        <div className="flex-1 overflow-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/model-selection" element={<ModelSelection />} />
            <Route path="/learning-styles" element={<LearningStyles />} />
            <Route path="/algorithm-selection" element={<AlgorithmSelection />} />
            <Route path="/memory-options" element={<MemoryOptions />} />
            <Route path="/research-mode" element={<ResearchMode />} />
            <Route path="/rewards-manager" element={<RewardsManager />} />
            <Route path="/training-schedule" element={<TrainingSchedule />} />
            <Route path="/monitoring-control" element={<MonitoringControl />} />
            <Route path="/video-training" element={<VideoTraining />} />
            <Route path="/advanced-logging" element={<AdvancedLogging />} />
            <Route path="/pipeline" element={<Pipeline />} />
            <Route path="/api-manager" element={<ApiManager />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/auto-learning" element={<AutoLearningMode />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;