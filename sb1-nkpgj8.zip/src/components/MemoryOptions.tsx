import React, { useState } from 'react';
import { Check, Info } from 'lucide-react';

const MemoryOptions = () => {
  const [selectedMemories, setSelectedMemories] = useState<string[]>([]);

  const memoryTypes = [
    { name: 'Continual Memory', impact: 'High retention of past knowledge' },
    { name: 'Task-Based Memory', impact: 'Efficient for multi-task learning' },
    { name: 'Multi-Memory', impact: 'Versatile for complex environments' },
    { name: 'Persistent Memory', impact: 'Long-term information storage' },
    { name: 'Episodic Memory', impact: 'Improved decision making from past experiences' },
    { name: 'Short-Term Memory', impact: 'Quick adaptation to recent information' },
    { name: 'Long-Term Memory', impact: 'Stable long-term knowledge retention' },
    { name: 'Working Memory', impact: 'Efficient processing of current tasks' },
    { name: 'Associative Memory', impact: 'Enhanced pattern recognition and recall' },
  ];

  const toggleMemory = (memory: string) => {
    setSelectedMemories(prev =>
      prev.includes(memory)
        ? prev.filter(m => m !== memory)
        : [...prev, memory]
    );
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Memory Options</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {memoryTypes.map((memory, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">{memory.name}</h3>
              <button
                className={`p-2 rounded-full ${
                  selectedMemories.includes(memory.name)
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-600'
                }`}
                onClick={() => toggleMemory(memory.name)}
              >
                <Check className="h-4 w-4" />
              </button>
            </div>
            <p className="text-sm text-gray-600 mb-2">Impact: {memory.impact}</p>
            <button className="text-blue-500 hover:text-blue-600 flex items-center">
              <Info className="h-4 w-4 mr-1" /> Learn more
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MemoryOptions;