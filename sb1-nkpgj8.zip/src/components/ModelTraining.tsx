import React, { useState, useEffect } from 'react';
import { Play, Pause, HelpCircle } from 'lucide-react';

const ModelTraining = () => {
  const [selectedStyle, setSelectedStyle] = useState('');
  const [isTraining, setIsTraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [projectedImprovement, setProjectedImprovement] = useState(0);
  const [realImprovement, setRealImprovement] = useState(0);

  const learningStyles = [
    { value: 'rl', label: 'Reinforcement Learning (RL)', projected: 15 },
    { value: 'maml', label: 'Meta-Learning (MAML)', projected: 20 },
    { value: 'curiosity', label: 'Curiosity-Driven Learning', projected: 18 },
    { value: 'self', label: 'Self-Supervised Learning', projected: 22 },
    { value: 'multimodal', label: 'Multimodal Learning', projected: 25 },
    { value: 'continual', label: 'Continual Learning', projected: 17 },
    { value: 'imitation', label: 'Imitation Learning', projected: 16 },
    { value: 'exploratory', label: 'Exploratory Learning', projected: 19 },
  ];

  useEffect(() => {
    // Fetch initial model state from the API
    fetch('/api/model/state')
      .then(response => response.json())
      .then(data => {
        setSelectedStyle(data.currentStyle);
        setProjectedImprovement(data.projectedImprovement);
        setRealImprovement(data.realImprovement);
      });
  }, []);

  const handleStyleChange = (e) => {
    const newStyle = e.target.value;
    setSelectedStyle(newStyle);
    
    // Update model style via API
    fetch('/api/model/style', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ style: newStyle }),
    })
      .then(response => response.json())
      .then(data => {
        setProjectedImprovement(data.projectedImprovement);
      });
  };

  const toggleTraining = () => {
    setIsTraining(!isTraining);
    
    // Start or stop training via API
    fetch('/api/model/train', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ training: !isTraining }),
    });
  };

  useEffect(() => {
    let interval;
    if (isTraining) {
      interval = setInterval(() => {
        // Fetch training progress from API
        fetch('/api/model/progress')
          .then(response => response.json())
          .then(data => {
            setProgress(data.progress);
            setRealImprovement(data.realImprovement);
          });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTraining]);

  return (
    <div className="p-6 bg-white rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">Model Training and Learning Styles</h2>
      <div className="mb-4">
        <label className="block mb-2 font-semibold">
          Select Learning Style
          <HelpCircle className="inline-block ml-1 h-4 w-4 text-gray-400 cursor-help" title="Choose a learning style for your AI model" />
        </label>
        <select
          value={selectedStyle}
          onChange={handleStyleChange}
          className="w-full p-2 border rounded"
        >
          <option value="">Select a style</option>
          {learningStyles.map(style => (
            <option key={style.value} value={style.value}>{style.label}</option>
          ))}
        </select>
      </div>
      <div className="mb-4">
        <button
          onClick={toggleTraining}
          className={`px-4 py-2 rounded ${isTraining ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'} text-white`}
        >
          {isTraining ? <Pause className="inline-block mr-2" /> : <Play className="inline-block mr-2" />}
          {isTraining ? 'Pause Training' : 'Start Training'}
        </button>
      </div>
      <div className="mb-4">
        <label className="block mb-2 font-semibold">Training Progress</label>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
        </div>
        <p className="text-sm text-gray-600 mt-1">{progress}% complete</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block mb-2 font-semibold">
            Projected Improvement
            <HelpCircle className="inline-block ml-1 h-4 w-4 text-gray-400 cursor-help" title="Estimated improvement based on the selected learning style" />
          </label>
          <p className="text-2xl font-bold text-blue-600">{projectedImprovement}%</p>
        </div>
        <div>
          <label className="block mb-2 font-semibold">
            Real-time Improvement
            <HelpCircle className="inline-block ml-1 h-4 w-4 text-gray-400 cursor-help" title="Actual improvement observed during training" />
          </label>
          <p className="text-2xl font-bold text-green-600">{realImprovement}%</p>
        </div>
      </div>
    </div>
  );
};

export default ModelTraining;