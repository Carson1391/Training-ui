import React, { useState } from 'react';
import { Info, Check } from 'lucide-react';

const AlgorithmSelection = () => {
  const [selectedAlgorithms, setSelectedAlgorithms] = useState<string[]>([]);

  const algorithms = [
    { name: 'Proximal Policy Optimization (PPO)', efficiency: 85 },
    { name: 'Advantage Actor-Critic (A2C)', efficiency: 78 },
    { name: 'Deep Q-Network (DQN)', efficiency: 82 },
    { name: 'Trust Region Policy Optimization (TRPO)', efficiency: 80 },
    { name: 'Soft Actor-Critic (SAC)', efficiency: 88 },
    { name: 'Twin Delayed DDPG (TD3)', efficiency: 86 },
    { name: 'Asynchronous Advantage Actor-Critic (A3C)', efficiency: 79 },
    { name: 'Distributed Distributional DDPG (D4PG)', efficiency: 84 },
    { name: 'Custom Algorithms', efficiency: 90 },
  ];

  const toggleAlgorithm = (algorithm: string) => {
    setSelectedAlgorithms(prev =>
      prev.includes(algorithm)
        ? prev.filter(a => a !== algorithm)
        : [...prev, algorithm]
    );
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Algorithm Selection</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {algorithms.map((algorithm, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">{algorithm.name}</h3>
              <button
                className={`p-2 rounded-full ${
                  selectedAlgorithms.includes(algorithm.name)
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-600'
                }`}
                onClick={() => toggleAlgorithm(algorithm.name)}
              >
                <Check className="h-4 w-4" />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">Efficiency: {algorithm.efficiency}%</p>
              <button className="text-blue-500 hover:text-blue-600 flex items-center">
                <Info className="h-4 w-4 mr-1" /> Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AlgorithmSelection;