import React from 'react';
import { ArrowRight, Database, Server, Cpu } from 'lucide-react';

const Pipeline = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Pipeline</h1>
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Integration Overview</h2>
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex flex-col items-center mb-4 md:mb-0">
            <Database className="h-12 w-12 text-blue-500 mb-2" />
            <span>Data Storage</span>
          </div>
          <ArrowRight className="h-8 w-8 text-gray-400 transform rotate-90 md:rotate-0" />
          <div className="flex flex-col items-center mb-4 md:mb-0">
            <Server className="h-12 w-12 text-green-500 mb-2" />
            <span>API Layer</span>
          </div>
          <ArrowRight className="h-8 w-8 text-gray-400 transform rotate-90 md:rotate-0" />
          <div className="flex flex-col items-center mb-4 md:mb-0">
            <Cpu className="h-12 w-12 text-red-500 mb-2" />
            <span>Processing</span>
          </div>
          <ArrowRight className="h-8 w-8 text-gray-400 transform rotate-90 md:rotate-0" />
          <div className="flex flex-col items-center">
            <Database className="h-12 w-12 text-purple-500 mb-2" />
            <span>Results Storage</span>
          </div>
        </div>
        <h2 className="text-xl font-semibold mb-4">FastAPI and Docker Containers</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-100 p-4 rounded">
            <h3 className="font-semibold mb-2">Data Ingestion Container</h3>
            <p className="text-sm">Handles data input and preprocessing</p>
          </div>
          <div className="bg-gray-100 p-4 rounded">
            <h3 className="font-semibold mb-2">Model Training Container</h3>
            <p className="text-sm">Manages model training and optimization</p>
          </div>
          <div className="bg-gray-100 p-4 rounded">
            <h3 className="font-semibold mb-2">Inference Container</h3>
            <p className="text-sm">Runs model inference on new data</p>
          </div>
          <div className="bg-gray-100 p-4 rounded">
            <h3 className="font-semibold mb-2">Results API Container</h3>
            <p className="text-sm">Serves results through FastAPI endpoints</p>
          </div>
        </div>
        <h2 className="text-xl font-semibold mt-8 mb-4">Pipeline Settings</h2>
        <div className="space-y-4">
          <div>
            <label className="block mb-2 font-semibold">Data Flow Configuration</label>
            <select className="w-full p-2 border rounded">
              <option>Sequential Processing</option>
              <option>Parallel Processing</option>
              <option>Hybrid Processing</option>
            </select>
          </div>
          <div>
            <label className="block mb-2 font-semibold">Error Handling</label>
            <select className="w-full p-2 border rounded">
              <option>Fail Fast</option>
              <option>Retry with Backoff</option>
              <option>Skip and Continue</option>
            </select>
          </div>
          <div>
            <label className="block mb-2 font-semibold">Logging Level</label>
            <select className="w-full p-2 border rounded">
              <option>Debug</option>
              <option>Info</option>
              <option>Warning</option>
              <option>Error</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pipeline;