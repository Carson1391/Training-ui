import React, { useState } from 'react';
import { Server, Play, AlertCircle, CheckCircle } from 'lucide-react';

const ApiManager = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState('');
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);

  const apiEndpoints = [
    { name: 'Model Selection API', url: '/api/model-selection' },
    { name: 'Learning Styles API', url: '/api/learning-styles' },
    { name: 'Algorithm Selection API', url: '/api/algorithm-selection' },
    { name: 'Memory Options API', url: '/api/memory-options' },
    { name: 'Research Mode API', url: '/api/research-mode' },
    { name: 'Rewards Manager API', url: '/api/rewards-manager' },
    { name: 'Training Schedule API', url: '/api/training-schedule' },
    { name: 'Monitoring Control API', url: '/api/monitoring-control' },
    { name: 'Video Training API', url: '/api/video-training' },
    { name: 'Advanced Logging API', url: '/api/advanced-logging' },
    { name: 'Pipeline API', url: '/api/pipeline' },
  ];

  const testEndpoint = () => {
    // Simulating API test
    setTimeout(() => {
      setTestResult(Math.random() > 0.5 ? 'success' : 'error');
    }, 1000);
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">API Manager (MLOps)</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">API Overview</h2>
          <ul className="space-y-2">
            {apiEndpoints.map((endpoint, index) => (
              <li
                key={index}
                className={`p-2 rounded cursor-pointer ${
                  selectedEndpoint === endpoint.url ? 'bg-blue-100' : 'hover:bg-gray-100'
                }`}
                onClick={() => setSelectedEndpoint(endpoint.url)}
              >
                <div className="flex items-center">
                  <Server className="h-5 w-5 mr-2 text-blue-500" />
                  <span>{endpoint.name}</span>
                </div>
                <div className="text-sm text-gray-500 ml-7">{endpoint.url}</div>
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Endpoint Testing</h2>
          {selectedEndpoint ? (
            <>
              <p className="mb-4">Selected Endpoint: {selectedEndpoint}</p>
              <button
                onClick={testEndpoint}
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 flex items-center"
              >
                <Play className="h-5 w-5 mr-2" />
                Test Endpoint
              </button>
              {testResult && (
                <div className={`mt-4 p-2 rounded ${testResult === 'success' ? 'bg-green-100' : 'bg-red-100'}`}>
                  {testResult === 'success' ? (
                    <div className="flex items-center text-green-700">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      Endpoint test successful
                    </div>
                  ) : (
                    <div className="flex items-center text-red-700">
                      <AlertCircle className="h-5 w-5 mr-2" />
                      Endpoint test failed
                    </div>
                  )}
                </div>
              )}
            </>
          ) : (
            <p>Select an endpoint to test</p>
          )}
        </div>
      </div>
      <div className="mt-6 bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">API Documentation</h2>
        <p className="mb-4">
          Auto-generated API documentation for developers. This section would typically include detailed information
          about each endpoint, request/response formats, and usage examples.
        </p>
        <button className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
          Generate API Docs
        </button>
      </div>
    </div>
  );
};

export default ApiManager;