import React, { useState } from 'react';
import { Search, Play, Pause } from 'lucide-react';

const ResearchMode = () => {
  const [keyword, setKeyword] = useState('');
  const [isResearching, setIsResearching] = useState(false);
  const [automatedTasks, setAutomatedTasks] = useState({
    conductResearch: false,
    conductExperiments: false,
    practiceCalculations: false,
    debugCode: false,
    performSimulations: false,
  });

  const toggleResearch = () => {
    setIsResearching(!isResearching);
  };

  const toggleTask = (task: keyof typeof automatedTasks) => {
    setAutomatedTasks(prev => ({ ...prev, [task]: !prev[task] }));
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Research Mode</h1>
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex mb-4">
          <input
            type="text"
            placeholder="Enter research keyword/topic"
            className="flex-grow p-2 border rounded-l-lg"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
          />
          <button
            className="bg-blue-500 text-white p-2 rounded-r-lg hover:bg-blue-600"
            onClick={toggleResearch}
          >
            {isResearching ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
          </button>
        </div>
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Automated Task Progression</h2>
          {Object.entries(automatedTasks).map(([task, isEnabled]) => (
            <div key={task} className="flex items-center mb-2">
              <input
                type="checkbox"
                id={task}
                checked={isEnabled}
                onChange={() => toggleTask(task as keyof typeof automatedTasks)}
                className="mr-2"
              />
              <label htmlFor={task} className="capitalize">{task.replace(/([A-Z])/g, ' $1').trim()}</label>
            </div>
          ))}
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-2">Progress Metrics</h2>
          <div className="bg-gray-100 p-4 rounded">
            <p>Research progress: 45%</p>
            <p>Knowledge gain: +15 points</p>
            <p>Efficiency improvement: 8%</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResearchMode;