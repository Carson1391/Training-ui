import React, { useState } from 'react';
import { PlusCircle, MinusCircle, Edit2 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const RewardsManager = () => {
  const [rewardsEnabled, setRewardsEnabled] = useState(true);
  const [manualReward, setManualReward] = useState(0);
  const [continuousRewardScript, setContinuousRewardScript] = useState('');

  const rewardData = [
    { name: 'Day 1', rewards: 4000 },
    { name: 'Day 2', rewards: 3000 },
    { name: 'Day 3', rewards: 5000 },
    { name: 'Day 4', rewards: 2780 },
    { name: 'Day 5', rewards: 1890 },
    { name: 'Day 6', rewards: 2390 },
    { name: 'Day 7', rewards: 3490 },
  ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Rewards Manager</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Rewards System</h2>
          <div className="flex items-center mb-4">
            <label className="mr-2">Enable Rewards:</label>
            <input
              type="checkbox"
              checked={rewardsEnabled}
              onChange={() => setRewardsEnabled(!rewardsEnabled)}
              className="form-checkbox h-5 w-5 text-blue-600"
            />
          </div>
          <div className="flex items-center mb-4">
            <input
              type="number"
              value={manualReward}
              onChange={(e) => setManualReward(Number(e.target.value))}
              className="border rounded p-2 mr-2"
            />
            <button className="bg-green-500 text-white p-2 rounded mr-2 hover:bg-green-600">
              <PlusCircle className="h-5 w-5" />
            </button>
            <button className="bg-red-500 text-white p-2 rounded hover:bg-red-600">
              <MinusCircle className="h-5 w-5" />
            </button>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Continuous Reward Script</h3>
            <textarea
              value={continuousRewardScript}
              onChange={(e) => setContinuousRewardScript(e.target.value)}
              className="w-full h-32 border rounded p-2"
              placeholder="Enter your reward script here..."
            />
            <button className="mt-2 bg-blue-500 text-white p-2 rounded hover:bg-blue-600 flex items-center">
              <Edit2 className="h-4 w-4 mr-1" /> Edit Script
            </button>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Reward Statistics</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={rewardData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="rewards" stroke="#8884d8" activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default RewardsManager;