import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Brain, Zap, GitBranch, Database, Search, Award, Calendar, Monitor, Video, BarChart2, PipelineIcon, Settings, Cpu } from 'lucide-react';

const Sidebar = () => {
  const menuItems = [
    { icon: Home, text: 'Dashboard', path: '/' },
    { icon: Brain, text: 'Model Selection', path: '/model-selection' },
    { icon: Zap, text: 'Learning Styles', path: '/learning-styles' },
    { icon: GitBranch, text: 'Algorithm Selection', path: '/algorithm-selection' },
    { icon: Database, text: 'Memory Options', path: '/memory-options' },
    { icon: Search, text: 'Research Mode', path: '/research-mode' },
    { icon: Award, text: 'Rewards Manager', path: '/rewards-manager' },
    { icon: Calendar, text: 'Training Schedule', path: '/training-schedule' },
    { icon: Monitor, text: 'Monitoring & Control', path: '/monitoring-control' },
    { icon: Video, text: 'Video Training', path: '/video-training' },
    { icon: BarChart2, text: 'Advanced Logging', path: '/advanced-logging' },
    { icon: PipelineIcon, text: 'Pipeline', path: '/pipeline' },
    { icon: Cpu, text: 'Auto-Learning Mode', path: '/auto-learning' },
    { icon: Settings, text: 'Settings', path: '/settings' },
  ];

  return (
    <div className="bg-gray-800 text-white w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out">
      <h1 className="text-2xl font-semibold text-center mb-6">AI Training UI</h1>
      <nav>
        {menuItems.map((item, index) => (
          <Link
            key={index}
            to={item.path}
            className="block py-2.5 px-4 rounded transition duration-200 hover:bg-gray-700 flex items-center"
          >
            <item.icon className="mr-3 h-5 w-5" />
            {item.text}
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;