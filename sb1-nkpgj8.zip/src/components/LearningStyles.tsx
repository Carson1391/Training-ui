import React, { useState } from 'react';
import { Info, Check } from 'lucide-react';

const LearningStyles = () => {
  const [selectedStyles, setSelectedStyles] = useState<string[]>([]);

  const learningStyles = [
    { name: 'Reinforcement Learning (RL)', description: 'Learning through interaction with an environment' },
    { name: 'Model-Agnostic Meta-Learning (MAML)', description: 'Learning to learn across tasks' },
    { name: 'Curiosity-Driven Learning', description: 'Exploration based on novelty or surprise' },
    { name: 'Continual Learning', description: 'Learning continuously from a stream of experiences' },
    { name: 'Exploratory Learning', description: 'Learning through active exploration of the environment' },
    { name: 'Multimodal Learning', description: 'Learning from multiple types of inputs or sensory modalities' },
    { name: 'Self-Supervised Learning', description: 'Learning without explicit labels by leveraging the structure in the data' },
    { name: 'Imitation Learning', description: 'Learning by observing and mimicking expert behavior' },
    { name: 'Self-Learning Mode', description: 'Includes RL, LL*, Curiosity, Continuous Learning, Self-Play, AutoML, Learn-to-Learn' },
  ];

  const toggleStyle = (style: string) => {
    setSelectedStyles(prev =>
      prev.includes(style)
        ? prev.filter(s => s !== style)
        : [...prev, style]
    );
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Learning Styles</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {learningStyles.map((style, index) => (
          <div key={index} className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold">{style.name}</h3>
              <button
                className={`p-2 rounded-full ${
                  selectedStyles.includes(style.name)
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-600'
                }`}
                onClick={() => toggleStyle(style.name)}
              >
                <Check className="h-4 w-4" />
              </button>
            </div>
            <p className="text-sm text-gray-600">{style.description}</p>
            <button className="mt-2 text-blue-500 hover:text-blue-600 flex items-center">
              <Info className="h-4 w-4 mr-1" /> Learn more
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LearningStyles;