import React from 'react';
import ModelTraining from '../components/ModelTraining';
import Scripts from '../components/Scripts';
import KnowledgeRetrieval from '../components/KnowledgeRetrieval';
import AlgorithmsAndAutomation from '../components/AlgorithmsAndAutomation';

const AITraining = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">AI Training Interface</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ModelTraining />
        <Scripts />
        <KnowledgeRetrieval />
        <AlgorithmsAndAutomation />
      </div>
    </div>
  );
};

export default AITraining;