import React, { useState } from 'react';
import { Calendar, Clock, CheckSquare, Play, Pause } from 'lucide-react';

const TrainingSchedule = () => {
  const [trainingMode, setTrainingMode] = useState('background');
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);
  const [isTraining, setIsTraining] = useState(false);
  const [trainingDuration, setTrainingDuration] = useState(60); // in minutes

  const presetTasks = [
    { id: 'coding', name: 'Coding Improvement and Debugging' },
    { id: 'problemSolving', name: 'General Problem-Solving' },
    { id: 'gameStrategy', name: 'Game-Specific Tasks (Reaction Time, Strategy Improvement)' },
    { id: 'dataAnalysis', name: 'Data Analysis and Interpretation' },
    { id: 'languageProcessing', name: 'Natural Language Processing' },
  ];

  const toggleTask = (taskId: string) => {
    setSelectedTasks(prev =>
      prev.includes(taskId)
        ? prev.filter(id => id !== taskId)
        : [...prev, taskId]
    );
  };

  const toggleTraining = () => {
    setIsTraining(!isTraining);
    if (!isTraining) {
      // Simulate starting a training session
      setTimeout(() => {
        setIsTraining(false);
        alert('Training session completed!');
      }, trainingDuration * 60 * 1000);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Training Schedule and Preset Tasks</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Training Mode</h2>
          <div className="flex space-x-4 mb-6">
            <button
              className={`flex items-center px-4 py-2 rounded ${
                trainingMode === 'background' ? 'bg-blue-500 text-white' : 'bg-gray-200'
              }`}
              onClick={() => setTrainingMode('background')}
            >
              <Calendar className="h-5 w-5 mr-2" />
              Background
            </button>
            <button
              className={`flex items-center px-4 py-2 rounded ${
                trainingMode === 'realtime' ? 'bg-blue-500 text-white' : 'bg-gray-200'
              }`}
              onClick={() => setTrainingMode('realtime')}
            >
              <Clock className="h-5 w-5 mr-2" />
              Real-Time
            </button>
          </div>
          <h2 className="text-xl font-semibold mb-4">Preset Tasks</h2>
          {presetTasks.map(task => (
            <div key={task.id} className="flex items-center mb-2">
              <input
                type="checkbox"
                id={task.id}
                checked={selectedTasks.includes(task.id)}
                onChange={() => toggleTask(task.id)}
                className="mr-2"
              />
              <label htmlFor={task.id}>{task.name}</label>
            </div>
          ))}
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Automated Training Session</h2>
          <div className="mb-4">
            <label className="block mb-2">Training Duration (minutes)</label>
            <input
              type="number"
              value={trainingDuration}
              onChange={(e) => setTrainingDuration(parseInt(e.target.value))}
              className="w-full p-2 border rounded"
              min="1"
            />
          </div>
          <button
            onClick={toggleTraining}
            className={`px-4 py-2 rounded ${isTraining ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'} text-white`}
          >
            {isTraining ? <Pause className="inline-block mr-2" /> : <Play className="inline-block mr-2" />}
            {isTraining ? 'Stop Training' : 'Start Training'}
          </button>
          {isTraining && (
            <p className="mt-2 text-sm text-gray-600">
              Training in progress. Estimated completion time: {new Date(Date.now() + trainingDuration * 60 * 1000).toLocaleTimeString()}
            </p>
          )}
        </div>
        <div className="bg-white rounded-lg shadow p-6 md:col-span-2">
          <h2 className="text-xl font-semibold mb-4">Progress Indicators</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">Overall Performance Increase</h3>
              <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '45%' }}></div>
              </div>
              <p className="text-sm text-gray-600 mt-1">45% improvement</p>
            </div>
            <div>
              <h3 className="font-semibold">Estimated Impact on Model</h3>
              <ul className="list-disc list-inside">
                <li>Coding skills: +20% efficiency</li>
                <li>Problem-solving: +15% accuracy</li>
                <li>Game strategy: +30% win rate</li>
                <li>Data analysis: +25% speed</li>
                <li>Language processing: +18% comprehension</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrainingSchedule;