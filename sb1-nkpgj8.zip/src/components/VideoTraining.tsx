import React, { useState, useEffect } from 'react';
import { Play, Pause, Plus, BarChart2, FileText } from 'lucide-react';

const VideoTraining = () => {
  const [videoUrl, setVideoUrl] = useState('');
  const [videoQueue, setVideoQueue] = useState<string[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [analysis, setAnalysis] = useState('');

  useEffect(() => {
    const socket = new WebSocket('ws://localhost:8000/ws/video-training');
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'transcription') {
        setTranscription(data.content);
      } else if (data.type === 'analysis') {
        setAnalysis(data.content);
      }
    };
    return () => socket.close();
  }, []);

  const addToQueue = () => {
    if (videoUrl) {
      setVideoQueue([...videoQueue, videoUrl]);
      setVideoUrl('');
      // Send video URL to backend for processing
      fetch('/api/video-training/queue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: videoUrl }),
      });
    }
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
    // Send play/pause command to backend
    fetch('/api/video-training/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: isPlaying ? 'pause' : 'play' }),
    });
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Video Training</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* ... (previous video queue and player code) ... */}
        <div className="bg-white rounded-lg shadow p-6 md:col-span-2">
          <h2 className="text-xl font-semibold mb-4">Video Analysis</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold mb-2">Transcription</h3>
              <div className="bg-gray-100 p-4 rounded h-40 overflow-y-auto">
                <p className="text-sm">{transcription}</p>
              </div>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Analysis</h3>
              <div className="bg-gray-100 p-4 rounded h-40 overflow-y-auto">
                <p className="text-sm">{analysis}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoTraining;