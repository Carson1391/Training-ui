import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Dashboard = () => {
  const data = [
    { name: 'Model A', performance: 4000, efficiency: 2400 },
    { name: 'Model B', performance: 3000, efficiency: 1398 },
    { name: 'Model C', performance: 2000, efficiency: 9800 },
    { name: 'Model D', performance: 2780, efficiency: 3908 },
    { name: 'Model E', performance: 1890, efficiency: 4800 },
  ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Model Performance</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="performance" fill="#8884d8" />
              <Bar dataKey="efficiency" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Recent Activities</h2>
          <ul className="space-y-2">
            <li>Model A training completed</li>
            <li>New dataset uploaded for Model B</li>
            <li>Algorithm optimization in progress</li>
            <li>Scheduled maintenance for GPU cluster</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;