import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { FileText, BarChart2 } from 'lucide-react';

const AdvancedLogging = () => {
  const performanceData = [
    { name: 'Day 1', accuracy: 65, speed: 70 },
    { name: 'Day 2', accuracy: 68, speed: 72 },
    { name: 'Day 3', accuracy: 75, speed: 78 },
    { name: 'Day 4', accuracy: 80, speed: 82 },
    { name: 'Day 5', accuracy: 85, speed: 85 },
    { name: 'Day 6', accuracy: 87, speed: 88 },
    { name: 'Day 7', accuracy: 90, speed: 92 },
  ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Advanced Logging, Stats, and Graphs</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Fine-Grained Logging</h2>
          <div className="bg-gray-100 p-4 rounded h-64 overflow-y-auto">
            <p className="text-sm font-mono">
              [2023-05-01 10:15:23] INFO: Model training started<br />
              [2023-05-01 10:15:25] DEBUG: Loading dataset: 10,000 samples<br />
              [2023-05-01 10:15:30] INFO: Epoch 1/10 started<br />
              [2023-05-01 10:16:45] INFO: Epoch 1/10 completed, loss: 0.0856<br />
              [2023-05-01 10:16:46] DEBUG: Saving checkpoint: model_epoch_1.pth<br />
              {/* Add more log entries as needed */}
            </p>
          </div>
          <button className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            Export Logs
          </button>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Performance Metrics</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="accuracy" stroke="#8884d8" activeDot={{ r: 8 }} />
              <Line type="monotone" dataKey="speed" stroke="#82ca9d" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-lg shadow p-6 md:col-span-2">
          <h2 className="text-xl font-semibold mb-4">Historical Performance</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Date</th>
                  <th className="p-2 text-left">Accuracy</th>
                  <th className="p-2 text-left">Speed</th>
                  <th className="p-2 text-left">Memory Usage</th>
                  <th className="p-2 text-left">CPU Usage</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="p-2">2023-05-01</td>
                  <td className="p-2">90%</td>
                  <td className="p-2">92 ms</td>
                  <td className="p-2">1.2 GB</td>
                  <td className="p-2">45%</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="p-2">2023-04-30</td>
                  <td className="p-2">87%</td>
                  <td className="p-2">98 ms</td>
                  <td className="p-2">1.1 GB</td>
                  <td className="p-2">42%</td>
                </tr>
                {/* Add more rows as needed */}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedLogging;