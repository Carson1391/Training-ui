import React, { useState } from 'react';
import { Check } from 'lucide-react';

const ModelSelection = () => {
  const [selectedModels, setSelectedModels] = useState<string[]>([]);

  const modelTypes = [
    'Science and Research',
    'Code and Programming',
    'Gaming',
    'NLP and Communication',
    'Business',
    'Computer Vision',
    'Robotics',
    'Data Analysis',
  ];

  const toggleModel = (model: string) => {
    setSelectedModels(prev =>
      prev.includes(model)
        ? prev.filter(m => m !== model)
        : [...prev, model]
    );
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Model Selection</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {modelTypes.map((model, index) => (
          <button
            key={index}
            className={`p-4 rounded-lg shadow ${
              selectedModels.includes(model)
                ? 'bg-blue-500 text-white'
                : 'bg-white hover:bg-gray-100'
            } transition duration-200 flex items-center justify-between`}
            onClick={() => toggleModel(model)}
          >
            <span>{model}</span>
            {selectedModels.includes(model) && <Check className="h-5 w-5" />}
          </button>
        ))}
      </div>
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Generic Presets</h2>
        <button className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-200">
          Apply Optimal Configuration
        </button>
      </div>
    </div>
  );
};

export default ModelSelection;