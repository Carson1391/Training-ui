import React, { useState } from 'react';
import { Monitor, Gamepad, Mic, Video, Play } from 'lucide-react';

const MonitoringControl = () => {
  const [realTimeMonitoring, setRealTimeMonitoring] = useState(false);
  const [gameMode, setGameMode] = useState(false);
  const [speechTraining, setSpeechTraining] = useState(false);
  const [videoLearning, setVideoLearning] = useState(false);
  const [autonomousPlay, setAutonomousPlay] = useState(false);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Monitoring & Control</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Real-Time Monitoring</h2>
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              id="realTimeMonitoring"
              checked={realTimeMonitoring}
              onChange={() => setRealTimeMonitoring(!realTimeMonitoring)}
              className="mr-2"
            />
            <label htmlFor="realTimeMonitoring" className="flex items-center">
              <Monitor className="h-5 w-5 mr-2" />
              Enable screen, keyboard, and mouse monitoring
            </label>
          </div>
          <p className="text-sm text-gray-600">
            When enabled, the model will monitor and learn from your interactions with the system.
          </p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Game Mode</h2>
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              id="gameMode"
              checked={gameMode}
              onChange={() => setGameMode(!gameMode)}
              className="mr-2"
            />
            <label htmlFor="gameMode" className="flex items-center">
              <Gamepad className="h-5 w-5 mr-2" />
              Enable Game Mode
            </label>
          </div>
          <p className="text-sm text-gray-600">
            In Game Mode, the model can observe and learn from your gameplay.
          </p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Speech Training and Feedback</h2>
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              id="speechTraining"
              checked={speechTraining}
              onChange={() => setSpeechTraining(!speechTraining)}
              className="mr-2"
            />
            <label htmlFor="speechTraining" className="flex items-center">
              <Mic className="h-5 w-5 mr-2" />
              Enable Speech Training
            </label>
          </div>
          <p className="text-sm text-gray-600">
            When enabled, you can provide verbal explanations and receive real-time feedback from the model.
          </p>
          {speechTraining && (
            <div className="mt-4">
              <textarea
                className="w-full p-2 border rounded"
                rows={4}
                placeholder="Speak or type your explanation here..."
              ></textarea>
              <button className="mt-2 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Send Feedback
              </button>
            </div>
          )}
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Video Learning</h2>
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              id="videoLearning"
              checked={videoLearning}
              onChange={() => setVideoLearning(!videoLearning)}
              className="mr-2"
            />
            <label htmlFor="videoLearning" className="flex items-center">
              <Video className="h-5 w-5 mr-2" />
              Enable Video Learning
            </label>
          </div>
          <p className="text-sm text-gray-600">
            When enabled, the model can learn from gameplay videos and tutorials.
          </p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Autonomous Play</h2>
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              id="autonomousPlay"
              checked={autonomousPlay}
              onChange={() => setAutonomousPlay(!autonomousPlay)}
              className="mr-2"
            />
            <label htmlFor="autonomousPlay" className="flex items-center">
              <Play className="h-5 w-5 mr-2" />
              Enable Autonomous Play
            </label>
          </div>
          <p className="text-sm text-gray-600">
            When enabled, the model can play the game autonomously to improve its skills.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MonitoringControl;