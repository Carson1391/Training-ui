import { openDB } from 'idb';

const dbPromise = openDB('AITrainingApp', 1, {
  upgrade(db) {
    db.createObjectStore('configurations');
    db.createObjectStore('trainingResults');
    db.createObjectStore('offlineActions');
  },
});

export async function saveConfiguration(config: any) {
  return (await dbPromise).put('configurations', config, 'currentConfig');
}

export async function getConfiguration() {
  return (await dbPromise).get('configurations', 'currentConfig');
}

export async function saveTrainingResult(result: any) {
  const db = await dbPromise;
  const tx = db.transaction('trainingResults', 'readwrite');
  const store = tx.objectStore('trainingResults');
  await store.add(result);
  return tx.done;
}

export async function getTrainingResults() {
  return (await dbPromise).getAll('trainingResults');
}

export async function addOfflineAction(action: any) {
  const db = await dbPromise;
  const tx = db.transaction('offlineActions', 'readwrite');
  const store = tx.objectStore('offlineActions');
  await store.add(action);
  return tx.done;
}

export async function getOfflineActions() {
  return (await dbPromise).getAll('offlineActions');
}

export async function clearOfflineActions() {
  return (await dbPromise).clear('offlineActions');
}