import React, { useState } from 'react';
import { Save, HelpCircle } from 'lucide-react';

const Settings = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [language, setLanguage] = useState('en');
  const [customAlgorithm, setCustomAlgorithm] = useState('');
  const [securityLevel, setSecurityLevel] = useState('medium');

  const handleSaveSettings = () => {
    // Implement save settings logic here
    console.log('Settings saved');
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">General Settings</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="flex items-center cursor-pointer">
                <span className="mr-2">Dark Mode</span>
                <div className="relative">
                  <input
                    type="checkbox"
                    className="sr-only"
                    checked={darkMode}
                    onChange={() => setDarkMode(!darkMode)}
                  />
                  <div className={`block w-14 h-8 rounded-full ${darkMode ? 'bg-blue-500' : 'bg-gray-300'}`}></div>
                  <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition ${darkMode ? 'transform translate-x-6' : ''}`}></div>
                </div>
              </label>
              <HelpCircle className="h-5 w-5 text-gray-400 cursor-help" title="Toggle between light and dark mode" />
            </div>
            <div className="flex items-center justify-between">
              <label className="flex items-center cursor-pointer">
                <span className="mr-2">Notifications</span>
                <div className="relative">
                  <input
                    type="checkbox"
                    className="sr-only"
                    checked={notifications}
                    onChange={() => setNotifications(!notifications)}
                  />
                  <div className={`block w-14 h-8 rounded-full ${notifications ? 'bg-blue-500' : 'bg-gray-300'}`}></div>
                  <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition ${notifications ? 'transform translate-x-6' : ''}`}></div>
                </div>
              </label>
              <HelpCircle className="h-5 w-5 text-gray-400 cursor-help" title="Enable or disable notifications" />
            </div>
            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <span className="mr-2">Language</span>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="border rounded p-1"
                >
                  <option value="en">English</option>
                  <option value="es">Español</option>
                  <option value="fr">Français</option>
                  <option value="de">Deutsch</option>
                </select>
              </label>
              <HelpCircle className="h-5 w-5 text-gray-400 cursor-help" title="Select your preferred language" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Advanced Settings</h2>
          <div className="space-y-4">
            <div>
              <label className="block mb-1">Custom Algorithm</label>
              <textarea
                value={customAlgorithm}
                onChange={(e) => setCustomAlgorithm(e.target.value)}
                className="w-full p-2 border rounded"
                rows={4}
                placeholder="Enter custom algorithm code..."
              ></textarea>
            </div>
            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <span className="mr-2">Security Level</span>
                <select
                  value={securityLevel}
                  onChange={(e) => setSecurityLevel(e.target.value)}
                  className="border rounded p-1"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </label>
              <HelpCircle className="h-5 w-5 text-gray-400 cursor-help" title="Set the security level for the application" />
            </div>
          </div>
        </div>
      </div>
      <div className="mt-6">
        <button
          onClick={handleSaveSettings}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 flex items-center"
        >
          <Save className="h-5 w-5 mr-2" />
          Save Settings
        </button>
      </div>
    </div>
  );
};

export default Settings;